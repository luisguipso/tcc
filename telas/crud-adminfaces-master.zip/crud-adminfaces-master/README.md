# crud-adminfaces

<p> Versão final do curso Web disponibilizado gratuitamente através do Youtube</p>

## Objetivo

Aprenda a desenvolver um crud RESPONSIVO, utilizando: Java, Bootstrap, Primefaces, AdminLTE, JSF, Hibernate e MySql.

## Tecnologias

* Java
* Bootstrap
* Primefaces
* AdminLTE
* JSF
* Hibernate
* MySql
* Eclipse
* Tomcat

## Link

[Acesso vídeos aulas](https://www.youtube.com/watch?v=P0uVDm9yZ7o&list=PL2OfKBFhHB0JrRd1YErlWh5epD6zDrCXU)

